package com.imdg.sqlloader;

import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.Ignition;

import com.imdg.model.Table1;

public final class DeltaLoadTest {

	public static void main(String[] args) {
		Ignite ignite = Ignition.start("JDBCLoadCluster-client.xml");
		IgniteCache<Integer, Table1> cache = ignite.getOrCreateCache("Table1Cache");
		cache.loadCache(null);
		System.out.println("Cache load complete");
	}

}
