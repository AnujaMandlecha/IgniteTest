package com.imdg.sqlloader;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.concurrent.atomic.AtomicInteger;

import javax.cache.Cache;
import javax.cache.integration.CacheLoaderException;
import javax.sql.DataSource;

import org.apache.ignite.IgniteException;
import org.apache.ignite.cache.store.CacheStoreAdapter;
import org.apache.ignite.lang.IgniteBiInClosure;
import org.h2.jdbcx.JdbcConnectionPool;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.RowMapper;

import com.imdg.model.Table1;


public class CacheJdbcTable1Store extends CacheStoreAdapter<Integer,Table1> {

	 /** Data source. */
    public static final DataSource DATA_SRC =
        JdbcConnectionPool.create("jdbc:sqlserver://localhost:8080;databaseName=test","test","test");

    /** Spring JDBC template. */
    private JdbcTemplate jdbcTemplate;

    /**
     * Constructor.
     *
     * @throws IgniteException If failed.
     */
    public CacheJdbcTable1Store() throws IgniteException {
        jdbcTemplate = new JdbcTemplate(DATA_SRC);
    }

    /** {@inheritDoc} */
    @Override public Table1 load(Integer key) {
        System.out.println(">>> Store load [key=" + key + ']');

        try {
            return jdbcTemplate.queryForObject("select * from Table1 ", new RowMapper<Table1>() {
                public Table1 mapRow(ResultSet rs, int rowNum) throws SQLException {
                    return new Table1(rs.getString(2), rs.getInt(3),rs.getLong(4),rs.getInt(5),rs.getTimestamp(6),rs.getTimestamp(7));
                }
            }, key);
        }
        catch (EmptyResultDataAccessException ignored) {
            return null;
        }
    }

    /** {@inheritDoc} */
    public void write(Cache.Entry<? extends Integer, ? extends Table1> entry) {
     //To Be Implemented
    }

    /** {@inheritDoc} */
    @Override public void delete(Object key) {
        System.out.println(">>> Store delete [key=" + key + ']');
        //To Be Implemented
    }

    /** {@inheritDoc} */
    @Override public void loadCache(final IgniteBiInClosure<Integer, Table1> clo, Object... args) {
        if (args == null || args.length == 0 || args[0] == null)
            throw new CacheLoaderException("Expected entry count parameter is not provided.");

        int entryCnt = (Integer)args[0];

        final AtomicInteger cnt = new AtomicInteger();

        jdbcTemplate.query("select * from Table1", new RowCallbackHandler() {
            @Override public void processRow(ResultSet rs) throws SQLException {
                Table1 t1 = new Table1(rs.getString(1), rs.getInt(2),rs.getLong(3),rs.getInt(4),rs.getTimestamp(5),rs.getTimestamp(6));

                clo.apply(rs.getInt(0), t1);

                cnt.incrementAndGet();
            }
        }, entryCnt);

        System.out.println(">>> Loaded " + cnt + " values into cache.");
    }
}


